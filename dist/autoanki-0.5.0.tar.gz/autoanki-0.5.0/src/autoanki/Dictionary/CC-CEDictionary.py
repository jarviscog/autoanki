# from Dictionary import Dictionary
#
# class CC_CEDictionary(Dictionary):
#
#     def __init__(self):
#         pass
#
#
